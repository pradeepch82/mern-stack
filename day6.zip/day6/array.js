
  var numbers=[1200,34,56,78,99,77];  //0 1 2 3 4 5

  var films=['SHOLAY','ABHIMAN','ABHINANDAN','SAGARSANGAM'];

  var cities=new Array(5);

  //addd elements
    cities.push("PUNE");
    cities.push("MUMBAI");
    cities.push("HYDERABAD");
    cities.push("CHENNAI");
    


//print the arrays
console.log("Numbers   :"+numbers);
console.log("Films     :"+films);
console.log("Cities    :"+cities);
console.log("====================================")
console.log("Numbers   :"+numbers.toString());
console.log("Films     :"+films.toString());
console.log("Cities    :"+cities.toString());

//traverse the array

console.log("==========Travers array by for loop============= ");
for(i=0;i<cities.length;i++)
console.log(cities[i]);


console.log("==========Traverse array by for in loop ========== ");
for(i in cities)
console.log(cities[i]);




console.log("==========Traverse array by forEach method using normal function========== ");
cities.forEach(function(element,index){
console.log(element+"    "+index);
});


console.log("==========Traverse array by forEach method using arrow function========== ");
cities.forEach((element,index)=>console.log(element+"    "+index));

console.log("==========Display those films whose name starts with A using filter and normal callback function ========== ");
var s=films.filter(function(element,index){
            return element.startsWith("A");    
      });
console.log(s);


console.log("==========Display those films whose name doesnot starts with A using filter and arrow callback function  ========== ");
var s=films.filter((element,index)=> !element.startsWith("A"));
console.log(s);


console.log("==========Convert those films in to lowercase whose name starts with A using map and normal callback function  ========== ");
films.map(function(element,index){
    if(element.startsWith("A"))
    films[index]=element.toLowerCase();
});

console.log(films);

console.log("==========Append 'Hi' to those filmse whose name doesnot starts with A using map and arrow callback function  ========== ");
films.map((element,index)=>{
    if(!element.startsWith("A"))
     films[index]=element.concat("  Hi");
});


console.log(films);

//sort the array
console.log("Before Sorting :"+cities);
cities.sort();
console.log("After Sorting :"+cities);

console.log("After Revers :"+cities.reverse());

/*
Array functions
=====================
length
map()
forEach()
filter()
toString()
sort()
reverse()

Tomorrow
===========

User Defined Objects
*/


