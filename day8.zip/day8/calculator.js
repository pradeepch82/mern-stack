var math=require("./math");

console.log(math.title);
console.log(math.add(100,20));
console.log(math.sub(100,20));
console.log(math.mul(100,20));
console.log(math.div(100,20));
console.log(math.mod(100,20));
console.log(math.message);

