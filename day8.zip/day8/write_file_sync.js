var fs = require("fs");


var data="Welcome To FS Module";

fs.writeFileSync("a.txt",data);

console.log("Program Ended....");





