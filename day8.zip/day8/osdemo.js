const os=require("os");

console.log("Number of cpus :",os.cpus());
console.log("Free Memory     :"+os.freemem());
console.log("Totla Memory     :"+os.totalmem());
console.log("Host Name ry     :"+os.hostname());
console.log("Home Directory  :"+os.homedir());
console.log("Temp   Directory :"+os.tmpdir());
console.log("Platform             :"+os.platform());



