var buffer1 = new Buffer('QABCD');
var buffer2 = new Buffer('AABCD');

var result = buffer1.compare(buffer2);

console.log(buffer1.toString());
console.log(buffer2.toString());



if(result < 0) {    
console.log(buffer1 +" comes before " + buffer2);
}
else if(result == 0){
console.log(buffer1 +" is same as " + buffer2);
}
else {
console.log(buffer1 +" comes after " + buffer2);
}