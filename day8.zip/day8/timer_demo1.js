function welcome(){
console.log("Welcome To Times module");
}

setTimeout(welcome,5000);


var timer=setInterval(welcome,2000);


setTimeout(end,10000);


function end(){
clearTimeout(timer);
}

console.log("timers Module Program Ended");