var ts=require("timers");

function welcome(){
console.log("Welcome To Times module");
}

ts.setTimeout(welcome,5000);


var timer=ts.setInterval(welcome,2000);


ts.setTimeout(end,10000);


function end(){
ts.clearTimeout(timer);
}

console.log("timers Module Program Ended");