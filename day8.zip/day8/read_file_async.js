var fs = require("fs");

/*
Callback :It's function that is passed as an argument to anotehr function.


*/

fs.readFile('calc.js', function (error, data) {

             if (error) return console.error(error);


             console.log(data);
             console.log(data.toString());
});


console.log("Program Ended");