



var s1="This is a JavaScript";
var s2='I like it';
var s3=new String("PRADEEPTECHNOSOFT");

console.log("s1  = "+s1);
console.log("s2  = "+s2);
console.log("s3  = "+s3);
console.log("Length of s1  = "+s1.length);
console.log("s1 in uppercase = "+s1.toUpperCase());
console.log("s1 in lowerrcase = "+s1.toLowerCase());
console.log("s1.startsWith('This')  = "+s1.startsWith('This'));
console.log("s1.endsWith('This')  = "+s1.endsWith('This'));
console.log("s1.indexOf('i') :"+s1.indexOf('i'));

console.log("s1.lastIndexOf('i') :"+s1.lastIndexOf('i'));
var p=s2.substring(0,7);
var q=s3.substring(0);
console.log("p  = "+p);
console.log("q  = "+q);
console.log("p+q = "+p+q);
console.log("s1.concat(s2) = "+s1.concat(" ",s2));
var str=" RAM ";
console.log("Before trim "+str.length);
str=str.trim();
console.log("After trim "+str.length);

/* 
A-Z   : 65 to 90
a-z   : 97 to 122 
0-9   : 40 t 48


*/
var student1="RAM";
var student2="RAHUL";
console.log("student1.localeCompare(student2) :"+student1.localeCompare(student2));












