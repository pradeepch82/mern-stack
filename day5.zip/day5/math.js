console.log("sqrt(100)    :"+Math.sqrt(100));
console.log("pow(10,2)    :"+Math.pow(10,2));
console.log("ceil(10.56)   :"+Math.ceil(10.56));
console.log("floor(10.56)   :"+Math.floor(10.56));
console.log("max(100,20,45)  :"+Math.max(100,20,45));
console.log("min(100,20,45)  :"+Math.min(100,20,45));
console.log("sin(0)  :"+Math.sin(0));
console.log("cos(0)  :"+Math.cos(0));
console.log(" Math.PI  :  :"+Math.PI);
console.log("abs(100)  :"+Math.abs(100));
console.log("abs(-100)  :"+Math.abs(-100));







