var a=100;
var b=new Number(100);


var c="ram";
var d=new String("RAHIM");

var p=100;
var q="100";



console.log(" a  ="+a);
console.log(" b  ="+b);
console.log(" typeof(a)  ="+typeof(a));
console.log(" typeof(b)  ="+typeof(b));
console.log(" typeof(c)  ="+typeof(c));
console.log(" typeof(d)  ="+typeof(d));
console.log(" typeof(d)  ="+typeof(d));
console.log(" MAX NUMBER VLAUE  :"+Number.MAX_VALUE);
console.log(" MIN NUMBER VLAUE  :"+Number.MIN_VALUE);

console.log("p==q   :"+(p==q));
console.log("p===q   :"+(p===q));












