/*

new Date()
new Date(value)
new Date(dateString)
new Date(dateObject)
new Date(year, monthIndex)
new Date(year, monthIndex, day)
new Date(year, monthIndex, day, hours)
new Date(year, monthIndex, day, hours, minutes)
new Date(year, monthIndex, day, hours, minutes, seconds)
new Date(year, monthIndex, day, hours, minutes, seconds, milliseconds)

*/

//var date=new Date();
var date=new Date("July 31,1982");
//var date=new Date("July 31,1982 03:24:00");


console.log("Today is :"+date);
console.log("Today is :"+date.toString());
console.log("Today is :"+date.toDateString());
console.log("Today is :"+date.toLocaleDateString());
console.log("Today is :"+date.toTimeString());
console.log("Today is :"+date.toLocaleTimeString());
console.log("Date  :"+date.getDate());
console.log("Month  :"+date.getMonth());
console.log("Year   :"+date.getFullYear());
console.log("Hours  :"+date.getHours());
console.log("Minutes:"+date.getMinutes());
console.log("Seconds:"+date.getSeconds());
console.log("MilliSeconds:"+date.getMilliseconds());
console.log("day of Week :"+date.getDay());












