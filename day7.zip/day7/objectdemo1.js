//we can create custom javascript objects using 3 ways

// 1. using function
// 2. using Object
// 3. JSON (Java Script Object Notation)


 //1. using function

//Object with static properties

function Employee(){
    //properties 
	this.id=101;
	this.name="Pradeep Chinchole";
	this.salary=12000;
	this.doj=new Date("2021 January,4");

	//function
	this.display=function(){

		console.log(" ---------------------------------- ");
		console.log(" Employe Details ");
		console.log(" ---------------------------------- ");
		console.log(" Id     "+this.id);
		console.log(" Name   "+this.name);
		console.log(" Salary "+this.salary);
		console.log(" DOJ    "+this.doj);
	} 


    this.toString=function (){
       return " Id :"+this.id+"  Name :"+this.name+"   Salary :"+this.salary+"   Doj :"+this.doj;
    }



}


//Object with dynamic properties
function Employee1(id,name,salary,doj){
    //properties 
	this.id=id;
	this.name=name;
	this.salary=salary;
	this.doj=doj;

	//function
	this.display=function(){

		console.log(" ---------------------------------- ");
		console.log(" Employe Details ");
		console.log(" ---------------------------------- ");
		console.log(" Id     "+this.id);
		console.log(" Name   "+this.name);
		console.log(" Salary "+this.salary);
		console.log(" DOJ    "+this.doj);
	} 

	this.toString=function (){
       return " Id :"+this.id+"  Name :"+this.name+"   Salary :"+this.salary+"   Doj :"+this.doj;
    }
    
}



var e1=new Employee();  //
var e2=new Employee1(234,"Suneel",34000,new Date("January 31,11"));

e1.display();
e2.display();


console.log(e1);
console.log(e2);
console.log("===========================")
console.log(e1.toString());
console.log(e2.toString());


