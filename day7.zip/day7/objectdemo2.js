//we can create custom javascript objects using 3 ways

// 1. using function
// 2. using Object
// 3. JSON (Java Script Object Notation)


 //2. using Object


var employee=new Object();

    employee.id=101;
    employee.name="Sachin Sharma";
    employee.salary=34000;
    employee.doj=new Date("July 31,1982");
    employee.isMarried=true;
    employee.address="Pune";
    employee.toString=function(){
    	       return " Id :"+this.id+"  Name :"+this.name+"   Salary :"+this.salary+"   Doj :"+this.doj.toDateString() +" IsMarried :"+this.isMarried+"  Address "+this.address;

    }


	employee.display=function(){

		console.log(" ---------------------------------- ");
		console.log(" Employe Details ");
		console.log(" ---------------------------------- ");
		console.log(" Id          "+this.id);
		console.log(" Name        "+this.name);
		console.log(" Salary      "+this.salary);
		console.log(" DOJ         "+this.doj);
		console.log(" Is Married  "+this.isMarried);
		console.log(" Address     "+this.address);

	} 


employee.display();
console.log(employee);
console.log(employee.toString());
