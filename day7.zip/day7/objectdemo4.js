


var technologies=[

                   {id:101,title:'Java',likes:0,dislikes:0},
                   {id:102,title:'.Net',likes:0,dislikes:0},
                   {id:103,title:'AWS',likes:0,dislikes:0},
                   {id:104,title:'Python',likes:0,dislikes:0},
                   {id:105,title:'PHP',likes:0,dislikes:0},
                   {id:106,title:'Microservices',likes:0,dislikes:0},
                   {id:107,title:'Node.js',likes:0,dislikes:0},

                ];


console.log(technologies);
console.log(technologies.filter((t,i)=>!t.title.startsWith('P')));


