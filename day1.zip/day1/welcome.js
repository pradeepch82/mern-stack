
let student1="Suneel";
let student2="Venkat";


console.log("Hi  "+student1+" Welcome To JS!!!!");
console.log('Hi '+student2+'Welcome To JS !!!!!');


//document.bgColor="GREEN";
//document.fgColor="BLUE";