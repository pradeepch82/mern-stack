let os=require("os");


console.log("Platform       : "+os.platform());
console.log("Free  memory   : "+os.freemem());
console.log("Total memory   : "+os.totalmem());
console.log("Home Directory : "+os.homedir());
console.log("Host name      : "+os.hostname());





